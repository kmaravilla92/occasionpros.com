@include('backoffice.event-posts.create',['event_post' => $event_post])
