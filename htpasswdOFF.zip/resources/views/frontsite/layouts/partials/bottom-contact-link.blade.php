<div class="section contact-link">
	<p>If you have any questions, click here to contact us. </p>
	<a class="trans-btn blue-btn" href="{{route('frontsite.contact-us')}}">CONTACT US</a>
</div>