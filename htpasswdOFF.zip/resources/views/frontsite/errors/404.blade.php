@extends('frontsite.layouts.main')
@section('content')

<section id="main-wrapper" class="content">
  <div class="section error-page">
    <div class="title-holder">
      <h3>
        <span>404</span>
        Oops! Page not found.
      </h3>
      <hr>
    </div>
  </div>
  <!-- /.error-page -->
</section>
@endsection